---
name: merch-design
description: Design branded staff merch (polo, t-shirt, cap) end to end – placement, flats on photo mockups, lifestyle shots on models, client PDF – or review someone else's merch work against our standard. Use when the user asks for merch, uniforms, polo/t-shirt/cap designs, "зроби мерч", "накинь лого на поло/кепку", "інтегруй логотип", "мерч для персоналу", "оціни мерч / порев'юй мокапи дизайнера", or sends logos + mockups for apparel.
---

# Merch design

All paths below are relative to this skill folder (`assets/` = reference library, `scripts/`, `references/`, `examples/`). Run scripts from the skill folder or pass absolute paths.

Two modes:
- **Create** – new merch from a brand package (logos, brandbook, patterns, mockups, references).
- **Review** – evaluate someone else's merch work → `references/review-checklist.md`.

Before anything, read `references/standard.md` (our approved standard: art direction, placement in cm, overlay technique, file formats, Pinterest, workflow). Expected-result references live in `assets/` (see its README) – calibrate on `results/merch-v3/` (the main reference: client deck with flats, caps and lifestyle shots per option) before showing anything; `prototype-sunrise-yoke/` is a secondary process example.

## Create – workflow

### 0. Intake
- Collect: logos as SVG (all versions), brandbook PDF, patterns (ask for 4000+ px or vector), WHITE photo mockups front/back/side 3000+ px (one light, plain background), cap ¾ and side, references, client feedback, garments and number of options. Missing mockups → use `assets/mockups/`.
- Work folder: `<your project>/merch/<option-name>/{flats,lifestyle,deck}`.

### 1. Concepts (before any render)
- 3–5 ideas, one line each, plus the angle matrix "front / back / side → what is visible". Idea bank: standard.md §1.
- Brief rules: one big idea; ≥2 logos for two-brand projects; every angle carries a brand element; palette colours; sides from the wearer's view.
- Show the concepts, get OK on the direction.

### 2. Flats in Claude
- Rasterise logos: `scripts/svg2png.py <svg> <png> <hex> <width>` (strips the white background rect, recolours).
- Trace seams and the collar on a contrast-boosted, gridded zoom of the mockup (no eyeballing: panels drawn by eye spilled 2–20 px over the seams).
- Write a spec JSON and render: `scripts/render_flat.py spec.json`. Example: `examples/sunrise-yoke/spec.json` (panels = yoke under the collar ending on the seams; prints = chest/back/sleeve logos). Scale for polo M on the reference mockup ≈ 9.5 px/cm.
- Placement map: adapt `scripts/annotate_placement.py`.
- Cap: re-skin a rendered cap (`scripts/cap_recolor.py`) or render from a light cap mockup; graphics follow the visor ellipse.
- QA on zoom (standard.md §6): logos match the vector, no halos/grey spots, white is white, panels on the seams, sizes realistic.
- Show 3–4 options per batch; a new placement = a new row of options, not an edit of old ones.

### 3. People
- `references/people-generation.md`: ChatGPT Image 2.0 via Codex first, one cast/scene for the project, flats as separate refs, one photo only, zoom QA, replace garbled small logos (`scripts/fix_ai_logos.py`).
- Each generation sends images to an external service and spends credits/quota – one at a time, no automatic retries.

### 4. Assembly
- Figma (manual polish by a designer) or Claude → PDF: adapt `scripts/build_deck.py` (1920×1080: cover with the group shot → per option flat board (polo 3 angles + cap) → «Идея» slide (idea, angles, logos, colours, placement map) → 2–3 lifestyle shots). Client language for all text. Output to `~/Downloads/`, then review every page.

## Review – workflow
Follow `references/review-checklist.md`: zoom every image, fill the criteria table with evidence, give top-3 fixes and production gaps. Compare against `assets/results/`.

## Rules learned the hard way
- Panels/colour zones follow the garment's construction: under the collar, end exactly on the sleeve seams.
- Chest logo lower and bigger than instinct: heart line, 8–10 cm.
- A collage reference → a collage output. Pass views separately.
- Never trust a model's text rendering of small logos.
- Never assume a key: image keys come from env vars (never print values).
