# Review mode – evaluating someone else's merch work

Input: flats / mockups / lifestyle shots / a client PDF from a designer or agency. Output: a short verdict – what works, what breaks the standard, top fixes. Look at every image on zoom (contrast-boost for seams), never judge from thumbnails.


Calibration references: `assets/results/` (approved kits, client decks, Sunrise Yoke incl. lifestyle) and `process/` (rejected iterations – typical mistakes).

## Output format
1. Verdict in one line (ready to show / needs fixes / rethink).
2. Table: criterion · status (ok / fix / fail) · evidence (which image, where) · fix.
3. Top-3 fixes in priority order.
4. Production gaps (what is missing for manufacturing).

## Criteria
**Idea**
- One big graphic idea per item (not 3–4 small logos – "baubles on a tree").
- Brand recognisable from afar and from every angle: front, back, side each carry a brand element.
- Thematic without literal ethnic clichés.

**Logos**
- Two-brand projects: ≥2 logos (corporate on chest, project brand big on back, monogram on sleeve; cap – one front, one side).
- Logos are taken from vector: no eaten letters, no white plates, no distortion.
- Logos small and calm; the graphic is the hero.

**Placement (size M)** – see standard.md §2
- Chest logo on the wearer's left, centre at the "heart line" (bottom of the placket), 8–10 cm wide.
- Sleeve monogram ~5.5 cm, centred on the outer sleeve, 1.5–3 cm above the rib.
- Back emblem 25–30 cm, top 6–8 cm below the collar / yoke seam.
- Side prints wrap 5–10 cm onto front and back.
- Panels (yoke, sleeves, colour blocks) go under the collar and end exactly on the seams.
- Cap: separate series for front-logo vs side-logo; graphics follow the visor curve.
- Sides named from the wearer's point of view.

**Colour**
- Fabric and ink from the brand palette; off-palette colours flagged (Pantone needed).
- Light ink on dark, dark ink on light; white is white, grey only in folds.

**Render quality**
- Photo mockup, not a vector flat; front/back/side from real photos, not a back faked from the front.
- No halos, ragged edges, grey blotches, visible tile seams; dark textures have enough contrast.
- Prints follow folds and perspective (cylindrical on sleeves/caps).
- AI lifestyle: one cast, consistent scene, garbled small text replaced, design present on every person.

**Presentation**
- Every option in 3 angles; final as a kit (polo + cap) with Idea / Feedback / Logos / Colours.
- Lifestyle shots for the client; text in the client's language.

**Production readiness**
- Technique per element (embroidery / print / sublimation), Pantone, size grading (S–XXL), techpacks.
