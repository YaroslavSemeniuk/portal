# Step 2 – people (lifestyle shots)

Priority (as of 2026-10-29): **ChatGPT Image 2.0** – the built-in `image_gen` tool in Codex, running on the ChatGPT subscription (no API key). Nano Banana Pro (`gemini-3-pro-image`) is a fallback only: in our test it gave more smearing and a more artificial look.

## Inputs
- Base photo with models: one cast and one scene for the whole project (every option uses the same people). Example: `assets/results/merch-v3/option1-lifestyle-2.jpg`.
- The approved flat as SEPARATE images: front, back, side. Never pass a 3-view collage – the model then returns a collage.

## Prompt rules
- "Output exactly ONE edited photograph with the same composition, framing and aspect ratio as image 1 – never a collage."
- List what changes: only the garment (colour, panels, prints) – with the placement rules spelled out (panel under the collar, ends exactly at the sleeve seams, symmetric shoulders, logo sizes and places).
- Name every person who must wear it, including people in the background or seen from the back.
- List what stays: faces, skin, hair, poses, hands, other clothing, scene, light, framing, realism. No new people.
- Prints: "screen-printed into the fabric – follows folds and light, not a flat sticker".
- Template: `examples/sunrise-yoke/people_prompt.txt`.

## Run (Codex)
Pass the prompt via stdin – `-i` takes several files and would swallow a trailing prompt:
```
echo "Use your built-in image generation tool exactly once to edit image 1 according to prompt.txt in this folder (attached in order: base.png, ref_front.png, ref_back.png, ref_side.png). Copy the result into this folder as out.png. Do not modify other files." \
| codex exec --skip-git-repo-check -C "$PWD" --sandbox workspace-write -i base.png -i ref_front.png -i ref_back.png -i ref_side.png -
```
Fallback: `scripts/gen_nano_fallback.py <name> prompt.txt base.png ref_*.png` (key: env var GEMINI_API_KEY, never print it).

## After each generation – zoom QA
- One generation → inspect on zoom → fix the prompt → next. No automatic retries.
- Check: single photo, every person has the design, panels under the collar and ending on the seams, both shoulders equal, back panel reaches both seams, logos present on everyone.
- Small text (e.g. "by ELYON") is usually garbled → replace with the vector logo (`scripts/fix_ai_logos.py`: fill the box from the surrounding fabric with a feathered edge, place the logo multiplied by the fabric shading).
- Check logo colour against the flat (models drift toward the accent colour).
- Reference of the expected result: `assets/results/prototype-sunrise-yoke/gpt_group_v2.jpg` (+ `compare_nano_vs_gpt.jpg`).
