# Merch design – скіл для команди YARSY

Готовий підхід до мерчу (поло, футболки, кепки): від ідеї і розміщення лого до кадрів на людях і PDF для клієнта. Плюс режим оцінки чужої роботи. Усередині – наш стандарт, скрипти і бібліотека референсів (`merch-design/assets/`).

## Що в архіві
- `merch-design/README-TEAM.md` – цей файл.
- `merch-design/SKILL.md` – інструкція для Claude (два режими: Create і Review).
- `merch-design/references/` – стандарт (art direction, розміщення в см, накладання, Pinterest), генерація людей, чекліст для рев'ю, схема вимірів.
- `merch-design/scripts/` – рендер флета з JSON-конфігу, лого SVG → PNG, заміна спотворених AI-лого, розмітка, збірка PDF.
- `merch-design/assets/` – референси:
  - `results/merch-v3/` – **головний еталон фінальної подачі** (PDF + усі кадри: флети, кепки, люди);
  - `results/final-kits/`, `results/prototype-sunrise-yoke/` – приклади флетів, розмітки, генерації;
  - `mockups/`, `pinterest/`, `input-package-example/` (+ `process/` у повній версії);
  - `standard/index.html` – стандарт у вигляді сторінки, відкрити в браузері.

Дві версії: `merch-design-team.zip` (повна, з усіма ітераціями) і `merch-design-team-lite.zip` (без ітерацій – для claude.ai, якщо повна не вантажиться).

## Встановлення
- **Claude Code:** розпакувати і покласти папку `merch-design` у `~/.claude/skills/`. Перезапустити Claude Code.
- **Claude Desktop / claude.ai:** ім'я внизу ліворуч → Settings → Capabilities → увімкнути «Run code in the cloud»; далі Settings → Skills → + Add → Upload skill → перетягнути zip (lite-версія, якщо повна завелика) → Upload. Покрокова PDF з кадрами – окремо.

## Що потрібно
- Python 3 з `Pillow` і `numpy` (`pip3 install pillow numpy`).
- Google Chrome (для конвертації SVG і збірки PDF).
- Для кадрів на людях – ChatGPT (Image 2.0): або Codex CLI з входом через ChatGPT, або вручну в застосунку ChatGPT (завантажити фото з моделями + флети перед/спина/бік окремо + промпт з `references/people-generation.md`).
- Nano Banana – тільки запасний варіант, потрібен власний ключ у змінній `GEMINI_API_KEY`.

## Як почати
- Нова задача: «Зроби мерч для <бренд>» + логотипи (SVG), брендбук, паттерни, білі фото-мокапи. Claude піде за кроками: концепти → флети → люди → PDF.
- Рев'ю: «Оціни мерч» + мокапи / PDF дизайнера → таблиця критеріїв, топ-3 правки, чого бракує для виробництва.
- Перед стартом корисно відкрити `assets/standard/index.html` і `assets/results/merch-v3/merch-v3.pdf` – так виглядає наш стандарт і бажаний результат.

Матеріали містять бренд клієнта (Essence of Africa / ZNZ Development) – тільки для внутрішньої роботи, не публікувати.
