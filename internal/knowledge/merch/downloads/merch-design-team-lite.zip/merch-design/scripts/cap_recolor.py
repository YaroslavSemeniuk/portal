# Example: re-skin an existing rendered cap (visor gets a texture, front letters recoloured). Paths/thresholds are per-project.
# Sunrise Yoke cap: Alexia's Red Earth cap base, visor gets the yoke texture, EOA recoloured to Dhow Wood.
import os
import numpy as np
from PIL import Image
LIB=os.environ.get('MERCH_LIB', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets'))
SRC=os.path.join(LIB,'results/final-kits/2_Red_Earth_кепка.jpg')
TEX=os.path.join(LIB,'input-package-example/паттерн1.png')
a=np.asarray(Image.open(SRC).convert('RGB')).astype(float); H,W=a.shape[:2]
R,G,B=a[...,0],a[...,1],a[...,2]
w=np.clip((R-G-25)/35,0,1)*np.clip((R-B-45)/35,0,1)
L=a.mean(-1); ref=np.median(L[w>0.9]); shade=(L/ref)[...,None]
yy=np.arange(H)[:,None]*np.ones((1,W))
visor=(w*(yy>=520))[...,None]; letters=(w*(yy<520))[...,None]
tex=np.asarray(Image.open(TEX).convert('RGB').resize((1600,920))).astype(float)
T=np.tile(tex,(H//920+1,W//1600+1,1))[:H,:W]; m=T.mean((0,1)); T=np.clip(m+(T-m)*1.3,0,255)
out=a*(1-visor)+np.clip(T*np.power(shade,1.2),0,255)*visor
dhow=np.array([107,87,68.])
out=out*(1-letters)+np.clip(dhow*shade,0,255)*letters
Image.fromarray(np.clip(out,0,255).astype('uint8')).save(os.environ.get('OUT','cap.jpg'),quality=92)
