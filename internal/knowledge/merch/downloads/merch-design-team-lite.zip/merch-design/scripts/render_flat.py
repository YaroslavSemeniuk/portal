"""Render a garment flat from a white photo mockup + a JSON spec.

Usage: python3 render_flat.py spec.json
Spec keys (coordinates in mockup pixels):
  mockup        path to the WHITE mockup (front/back/side on a plain warm background)
  out           output png path
  body_colour   hex for the fabric, e.g. "#F2ECE0"
  panels        [{"polygons": [[[x,y],...]], "texture": png | null, "colour": hex | null,
                  "texture_scale": [w,h], "contrast": 1.3}]   – yokes, sleeves, colour blocks
  cutouts       [[[x,y],...]]   – collar polygons cut OUT of every panel (panels go UNDER the collar)
  prints        [{"png": transparent logo png, "cx": x, "top": y, "width": px,
                  "crop": [l,t,r,b] | null, "rot": deg}]
Trace seams and collar on a contrast-boosted zoom first (see references/standard.md, «Накладання»).
"""
import json, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

def hexc(h): return np.array([int(h[i:i+2], 16) for i in (1, 3, 5)], float)

def fabric_mask(img):
    a = np.asarray(img).astype(float); L = a.mean(-1); warm = a[..., 0] - a[..., 2]
    bg = Image.fromarray((((warm >= 3.5) & (L <= 232)) * 255).astype('uint8'))
    bg = bg.filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.MinFilter(3))
    W, H = bg.size
    for pts in [[(x, y) for x in range(0, W, 40) for y in (0, H - 1)], [(x, y) for y in range(0, H, 40) for x in (0, W - 1)]]:
        for p in pts:
            if bg.getpixel(p) == 255: ImageDraw.floodfill(bg, p, 128)
    fab = Image.fromarray(((np.asarray(bg) != 128) * 255).astype('uint8'))
    return np.asarray(fab.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(0.8))).astype(float) / 255

def main(spec_path):
    sp = json.load(open(spec_path))
    src = Image.open(sp['mockup']).convert('RGB'); W, H = src.size
    a = np.asarray(src).astype(float); L = a.mean(-1)
    fab = fabric_mask(src)
    ref = np.percentile(L[fab > 0.9], 80); shade = np.clip(L / ref, 0, 1.08)[..., None]
    out = a * (1 - fab[..., None]) + hexc(sp['body_colour']) * shade * fab[..., None]
    cut = Image.new('L', (W, H), 0); c = ImageDraw.Draw(cut)
    for poly in sp.get('cutouts', []): c.polygon([tuple(p) for p in poly], fill=255)
    cut = np.asarray(cut)
    for pn in sp.get('panels', []):
        m = Image.new('L', (W, H), 0); d = ImageDraw.Draw(m)
        for poly in pn['polygons']: d.polygon([tuple(p) for p in poly], fill=255)
        m = Image.fromarray(np.minimum(np.asarray(m), 255 - cut).astype('uint8')).filter(ImageFilter.GaussianBlur(0.9))
        m = (np.asarray(m).astype(float) / 255 * fab)[..., None]
        if pn.get('texture'):
            tw, th = pn.get('texture_scale', [1300, 747])
            tx = np.asarray(Image.open(pn['texture']).convert('RGB').resize((tw, th))).astype(float)
            T = np.tile(tx, (H // th + 1, W // tw + 1, 1))[:H, :W]
            mu = T.mean((0, 1)); T = np.clip(mu + (T - mu) * pn.get('contrast', 1.3), 0, 255)
            fill = T * np.power(shade, 1.4)
        else:
            fill = hexc(pn['colour']) * np.power(shade, 1.4)
        out = out * (1 - m) + fill * m
    rng = np.random.default_rng(0)
    for pr in sp.get('prints', []):
        g = Image.open(pr['png']).convert('RGBA')
        if pr.get('crop'): g = g.crop(tuple(pr['crop']))
        g = g.crop(g.getbbox()); w = pr['width']
        g = g.resize((w, round(g.height * w / g.width)), Image.LANCZOS)
        if pr.get('rot'): g = g.rotate(pr['rot'], expand=True, resample=Image.BICUBIC)
        x0, y0 = int(pr['cx'] - g.width / 2), int(pr['top'])
        ga = np.asarray(g).astype(float)
        sl = (slice(y0, y0 + g.height), slice(x0, x0 + g.width))
        al = ga[..., 3:4] / 255 * fab[sl][..., None]
        ink = ga[..., :3] * np.power(shade[sl], 1.1) + rng.normal(0, 3, ga[..., :3].shape)
        out[sl] = out[sl] * (1 - al * 0.95) + ink * al * 0.95
    Image.fromarray(np.clip(out, 0, 255).astype('uint8')).save(sp['out'])
    print(sp['out'])

if __name__ == '__main__': main(sys.argv[1])
