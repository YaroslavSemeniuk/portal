import os
import sys,re,subprocess,os,tempfile
import glob as _glob
def _find_chrome():
    c = [os.environ.get('CHROME_BIN', '')] + sorted(_glob.glob(os.path.expanduser('~/Library/Caches/ms-playwright/chromium_headless_shell-*/*/chrome-headless-shell')), reverse=True) + [
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/usr/bin/google-chrome', '/usr/bin/chromium']
    return next((p for p in c if p and os.path.exists(p)), 'google-chrome')
CH = _find_chrome()
def render(src,out,color,width):
    s=open(src).read()
    m=re.search(r'viewBox="([\d.\s-]+)"',s); vb=[float(x) for x in m.group(1).split()]
    s=re.sub(r'<rect[^>]*fill="white"[^>]*/>','',s,count=1)
    s=re.sub(r'fill="(?!none)[^"]+"',f'fill="{color}"',s)
    s=re.sub(r'stroke="(?!none)[^"]+"',f'stroke="{color}"',s)
    h=round(width*vb[3]/vb[2])
    s=re.sub(r'<svg[^>]*?width="[^"]+"',f'<svg width="{width}"',s,count=1)
    s=re.sub(r'(<svg[^>]*?)height="[^"]+"',rf'\1height="{h}"',s,count=1)
    html=f'<html><body style="margin:0;background:transparent">{s}</body></html>'
    f=tempfile.NamedTemporaryFile('w',suffix='.html',delete=False);f.write(html);f.close()
    subprocess.run([CH,'--headless','--disable-gpu','--hide-scrollbars','--default-background-color=00000000',f'--window-size={width},{h}',f'--screenshot={out}','file://'+f.name],capture_output=True)
    print(out,width,h)
if __name__=='__main__': render(sys.argv[1],sys.argv[2],sys.argv[3],int(sys.argv[4]))
