# FALLBACK only (Nano Banana Pro). Priority is ChatGPT Image 2.0 via Codex – see references/people-generation.md.
# One Nano Banana Pro edit. Usage: python3 gen_nano.py <name> <prompt.txt> <img1> [img2 ...]
from pathlib import Path
import os,base64,json,urllib.request,urllib.error,datetime,hashlib,sys
HERE=Path(__file__).parent
key=os.environ['GEMINI_API_KEY']
name,prompt,inputs=sys.argv[1],Path(sys.argv[2]).read_text(),[Path(p) for p in sys.argv[3:]]
report={'model':'gemini-3-pro-image','name':name,'prompt':prompt,'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in inputs],'requested_size':'2K','status':'submitting','submitted_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'automatic_retries':0}
parts=[{'text':prompt}]+[{'inline_data':{'mime_type':'image/png','data':base64.b64encode(p.read_bytes()).decode()}} for p in inputs]
payload={'contents':[{'parts':parts}],'generationConfig':{'responseModalities':['IMAGE'],'imageConfig':{'imageSize':'2K','aspectRatio':'1:1'}}}
req=urllib.request.Request('https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image:generateContent',data=json.dumps(payload).encode(),headers={'x-goog-api-key':key,'Content-Type':'application/json'})
try:
    data=json.loads(urllib.request.urlopen(req,timeout=300).read())
    img=next(p['inlineData'] for c in data['candidates'] for p in c['content']['parts'] if 'inlineData' in p)
    out=HERE/f"{name}.{'png' if 'png' in img['mimeType'] else 'jpg'}"; out.write_bytes(base64.b64decode(img['data']))
    from PIL import Image; report.update(status='completed',output=str(out),dimensions=Image.open(out).size,usage=data.get('usageMetadata'))
except urllib.error.HTTPError as e: report.update(status='http_error',code=e.code,body=e.read().decode()[:500])
except Exception as e: report.update(status='error',error=repr(e)[:500])
(HERE/f'{name}.request.json').write_text(json.dumps(report,ensure_ascii=False,indent=1))
print(report['status'],report.get('output'),report.get('dimensions'),report.get('code'),report.get('error'))
