# Example: draw the placement map (sizes, offsets) on a rendered flat. Coordinates are per-mockup.
from PIL import Image, ImageDraw, ImageFont
im=Image.open('sunrise_yoke_polo.png').convert('RGB'); d=ImageDraw.Draw(im)
f=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',15)
C=(29,120,200)
def box(b,label,dx=0,dy=-22):
    x,y,w,h=b; d.rectangle([x-3,y-3,x+w+3,y+h+3],outline=C,width=2); d.text((x+dx,y+dy),label,fill=C,font=f)
def hline(x1,x2,y,label):
    d.line([(x1,y),(x2,y)],fill=C,width=2); d.line([(x1,y-6),(x1,y+6)],fill=C,width=2); d.line([(x2,y-6),(x2,y+6)],fill=C,width=2); d.text(((x1+x2)/2-len(label)*4,y+6),label,fill=C,font=f)
def vline(x,y1,y2,label):
    d.line([(x,y1),(x,y2)],fill=C,width=2); d.line([(x-6,y1),(x+6,y1)],fill=C,width=2); d.line([(x-6,y2),(x+6,y2)],fill=C,width=2); d.text((x+8,(y1+y2)/2-8),label,fill=C,font=f)
box((412,302,95,16),'груди: 10 см',0,-24)
d.line([(333,330),(600,330)],fill=C,width=1); d.text((520,334),'лінія серця = низ планки',fill=C,font=f)
hline(333,460,365,'~13 см від центру')
vline(1062,213,272,'6 см')
box((938,272,247,178),'спина: 26 см',70,184)
d.text((850,222),'шов кокетки ~12 см від коміра',fill=C,font=f)
d.text((600,120),'кокетка закінчується',fill=C,font=f); d.text((600,137),'на шві рукава',fill=C,font=f)
d.line([(598,135),(566,186)],fill=C,width=1)
box((1693,300,50,18),'рукав: 5,5 см',-20,-26)
vline(1760,318,334,'1,5 см до манжети')
im.save('sunrise_yoke_placement.png')
