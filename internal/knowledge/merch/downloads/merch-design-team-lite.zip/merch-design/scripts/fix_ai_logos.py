# Example from Sunrise Yoke: erase AI-garbled logo boxes and place vector logos shaded by the fabric.
# fill()/place() are reusable; the box coordinates at the bottom are per-image – trace them on a gridded zoom.
# Replace AI-garbled logos on generated lifestyle panels with the vector logos (shaded by the fabric).
import numpy as np, sys
from PIL import Image, ImageFilter
FL='../flats/'
def fill(a,x0,y0,x1,y1):
    top=a[y0-1,x0:x1];bot=a[y1,x0:x1];lef=a[y0:y1,x0-1];rig=a[y0:y1,x1]
    h=y1-y0;w=x1-x0
    ty=np.linspace(0,1,h)[:,None,None];tx=np.linspace(0,1,w)[None,:,None]
    v=top[None]*(1-ty)+bot[None]*ty; hh=lef[:,None]*(1-tx)+rig[:,None]*tx
    patch=(v+hh)/2
    ring=np.concatenate([a[y0-6:y0-1,x0:x1].reshape(-1,3),a[y1+1:y1+6,x0:x1].reshape(-1,3)])
    # fine grain only (ring std includes shading gradients, so measure high-frequency part)
    hf=np.diff(a[y0-8:y0-1,x0:x1].mean(-1),axis=1).std()/1.414
    patch=patch+np.random.normal(0,hf*0.8,(h,w,1))
    # feather the patch edge into the original
    m=np.ones((h,w));f=10
    r=np.minimum(np.minimum(np.arange(h)[:,None],np.arange(h)[::-1][:,None]),np.minimum(np.arange(w)[None],np.arange(w)[::-1][None]))
    m=np.clip(r/f,0,1)[...,None]
    a[y0:y1,x0:x1]=a[y0:y1,x0:x1]*(1-m)+patch*m
def place(a,png,x0,y0,width,rot=0):
    g=Image.open(png).convert('RGBA'); g=g.crop(g.getbbox())
    g=g.resize((width,round(g.height*width/g.width)),Image.LANCZOS)
    if rot: g=g.rotate(rot,expand=True,resample=Image.BICUBIC)
    g=g.filter(ImageFilter.GaussianBlur(0.4)); ga=np.asarray(g).astype(float)
    reg=a[y0:y0+g.height,x0:x0+g.width]; L=reg.mean(-1,keepdims=True)
    shade=np.clip(L/np.percentile(L,70),0.6,1.1)
    al=ga[...,3:4]/255*0.92
    a[y0:y0+g.height,x0:x0+g.width]=reg*(1-al)+ga[...,:3]*shade*al
np.random.seed(1)
# panel 2: chest
a=np.asarray(Image.open('SY_lifestyle_01_panel2.jpg').convert('RGB')).astype(float)
fill(a,298,498,456,556)
place(a,FL+'znz_dw.png',318,512,122,rot=-1.5)
Image.fromarray(np.clip(a,0,255).astype('uint8')).save('SY_lifestyle_02_front.jpg',quality=95)
# panel 3: back
a=np.asarray(Image.open('SY_lifestyle_01_panel3.jpg').convert('RGB')).astype(float)
fill(a,240,490,545,712)
place(a,FL+'main_dw.png',266,508,252)
Image.fromarray(np.clip(a,0,255).astype('uint8')).save('SY_lifestyle_03_back.jpg',quality=95)
