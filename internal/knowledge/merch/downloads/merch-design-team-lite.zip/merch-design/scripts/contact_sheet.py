import sys,glob
from PIL import Image
out=sys.argv[1];W=int(sys.argv[2]);cols=int(sys.argv[3]);fs=sys.argv[4:]
cw=W//cols;th=[]
for f in fs:
  im=Image.open(f).convert('RGB');im.thumbnail((cw,cw));th.append(im)
rows=[th[i:i+cols] for i in range(0,len(th),cols)]
H=sum(max(t.height for t in r) for r in rows)
s=Image.new('RGB',(W,H),'white');y=0
for r in rows:
  for j,t in enumerate(r): s.paste(t,(j*cw,y))
  y+=max(t.height for t in r)
s.save(out,quality=65);print(out,s.size)
