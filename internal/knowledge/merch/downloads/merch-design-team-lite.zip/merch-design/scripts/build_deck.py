import os
# Example deck builder (1920x1080 slides -> PDF via headless Chromium). Copy into the project folder and edit paths/texts.
# Builds the client deck (Alexia's format: 1920x1080, flat board + lifestyle) and prints it to PDF.
import subprocess, os, glob
COMPARE=os.environ.get('COMPARE')=='1'
from pathlib import Path
HERE=Path(__file__).parent; ROOT=HERE.parent
import glob as _glob
def _find_chrome():
    c = [os.environ.get('CHROME_BIN', '')] + sorted(_glob.glob(os.path.expanduser('~/Library/Caches/ms-playwright/chromium_headless_shell-*/*/chrome-headless-shell')), reverse=True) + [
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/usr/bin/google-chrome', '/usr/bin/chromium']
    return next((p for p in c if p and os.path.exists(p)), 'google-chrome')
CH = _find_chrome()
# final, logo-checked shots only: SY_cover.jpg (group) and SY_lifestyle_0N_<view>.jpg (N>=2)
cover=sorted(glob.glob(str(ROOT/'lifestyle/SY_cover.jpg')))
shots=sorted(glob.glob(str(ROOT/'lifestyle/SY_lifestyle_0[2-9]_*.jpg')))
def rel(p): return os.path.relpath(p,HERE)
slides=[]
V2=ROOT/'lifestyle/v2'
if COMPARE:
    slides.append(f'<section class="cover2"><div class="ct"><div class="kicker">Essence of Africa · мерч</div><div class="title">Sunrise Yoke</div><div class="sub">Поло + кепка</div></div><img src="{rel(V2/'gpt_group_v2.png')}"></section>')
elif cover:
    slides.append(f'<section class="cover"><img src="{rel(cover[0])}"><div class="brand">Sunrise Yoke</div></section>')
slides.append(f'''<section><h2>Sunrise Yoke</h2>
<div class="board"><img class="polo" src="{rel(ROOT/'flats/sunrise_yoke_polo.png')}"><img class="cap" src="{rel(ROOT/'flats/sunrise_yoke_cap.jpg')}"></div></section>''')
slides.append(f'''<section><h2>Sunrise Yoke · Идея</h2>
<div class="concept"><div class="txt">
<p class="big">Красная земля на плечах – и солнце, которое поднимается под ней.</p>
<dl><dt>Идея</dt><dd>Один крупный жест: фактурная кокетка Red Earth через плечи. Она уходит под воротник и заканчивается точно на швах рукавов. На спине под ней поднимается дуга солнца из логотипа Essence of Africa.</dd>
<dt>С любого ракурса</dt><dd>Спереди – полосы Red Earth на плечах и ZNZ Development. Сзади – кокетка и крупный логотип. Сбоку – плечо Red Earth и EOA на рукаве.</dd>
<dt>Логотипы</dt><dd>Поло: ZNZ Development на груди, Essence of Africa на спине, EOA на рукаве. Кепка: EOA спереди, ZNZ сбоку.</dd>
<dt>Цвета</dt><dd>Корпус Limestone, кокетка и козырёк Red Earth, печать Dhow Wood.</dd></dl></div>
<img src="{rel(ROOT/'flats/sunrise_yoke_placement_ru.png')}"></div></section>''')
if COMPARE:
    slides.append(f'''<section><h2>Sunrise Yoke · сравнение генерации</h2><div class="cmp">
<figure><img src="{rel(V2/'gpt_group_v2.png')}"><figcaption>GPT ImageGen (ChatGPT)</figcaption></figure>
<figure><img src="{rel(V2/'nano_group_v2.jpg')}"><figcaption>Nano Banana Pro (gemini-3-pro-image)</figcaption></figure></div></section>''')
if shots:
    imgs=''.join(f'<img src="{rel(p)}">' for p in shots[:3])
    slides.append(f'<section><h2>Sunrise Yoke</h2><div class="life">{imgs}</div></section>')
html=f'''<!doctype html><html><head><meta charset="utf-8">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:wght@400;500&family=Inter:wght@400;500&display=swap">
<style>
@page{{size:1920px 1080px;margin:0}}
*{{box-sizing:border-box}}body{{margin:0;background:#fff;font-family:Inter,sans-serif;color:#1D1A19}}
section{{width:1920px;height:1080px;padding:80px 80px;page-break-after:always;position:relative;overflow:hidden}}
h2{{font:500 34px 'Source Serif 4',Georgia,serif;margin:0 0 40px}}
.board{{background:#DDDCD7;height:840px;display:flex;align-items:center;justify-content:center;gap:24px;padding:40px}}
.board .polo{{width:1220px;flex:none}}.board .cap{{width:436px;flex:none;border-radius:4px}}
.cover{{padding:0}}.cover img{{width:100%;height:100%;object-fit:cover}}
.brand{{position:absolute;left:60px;top:48px;font:500 30px 'Source Serif 4',serif;color:#fff;letter-spacing:.04em;text-shadow:0 1px 8px #0005}}
.concept{{display:grid;grid-template-columns:560px 1fr;gap:56px;align-items:start}}.concept img{{width:100%;background:#E6E3DE}}
.big{{font:500 40px/1.2 'Source Serif 4',serif;margin:0 0 36px}}
dl{{margin:0;display:grid;gap:8px 0}}dt{{font-size:13px;letter-spacing:.14em;text-transform:uppercase;color:#6B5744;margin-top:18px}}dd{{margin:0;font-size:19px;line-height:1.5}}
.life{{display:flex;gap:16px;height:840px}}.life img{{flex:1;min-width:0;height:100%;object-fit:cover;object-position:center top}}
.cover2{{padding:0;display:grid;grid-template-columns:1fr 1143px}}.cover2 img{{width:1143px;height:1080px;object-fit:cover}}
.ct{{padding:96px 80px;display:flex;flex-direction:column;justify-content:flex-end}}.kicker{{font-size:15px;letter-spacing:.18em;text-transform:uppercase;color:#6B5744}}
.title{{font:500 84px/1 'Source Serif 4',serif;margin:18px 0}}.sub{{font-size:22px;color:#6B5744}}
.cmp{{display:flex;gap:24px;height:860px}}.cmp figure{{margin:0;flex:1;display:flex;flex-direction:column;gap:12px;min-width:0}}.cmp img{{width:100%;height:810px;object-fit:cover;object-position:center top}}
figcaption{{font-size:16px;letter-spacing:.06em;color:#6B5744}}
</style></head><body>{''.join(slides)}</body></html>'''
DECK=HERE/('deck_compare.html' if COMPARE else 'deck.html'); DECK.write_text(html)
out=Path.home()/('Downloads/Sunrise_Yoke_merch_GPT_vs_Nano.pdf' if COMPARE else 'Downloads/Sunrise_Yoke_merch.pdf')
subprocess.run([CH,'--headless','--disable-gpu','--no-pdf-header-footer',f'--print-to-pdf={out}','file://'+str(DECK)],capture_output=True,timeout=120)
print(len(slides),'slides ->',out, out.exists() and out.stat().st_size)
